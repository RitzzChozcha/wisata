package com.example.tawisatabatam;

import com.example.tawisatabatam.model.ModelMain;

public interface onSelected {
    void onSelected(ModelMain mdlMain);
}
