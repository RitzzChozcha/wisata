package com.example.tawisatabatam.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.tawisatabatam.R;

public class WisataActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wisata);
    }
}