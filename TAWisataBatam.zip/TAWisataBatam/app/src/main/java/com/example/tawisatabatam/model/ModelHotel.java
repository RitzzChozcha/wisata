package com.example.tawisatabatam.model;

public class ModelHotel {
}
