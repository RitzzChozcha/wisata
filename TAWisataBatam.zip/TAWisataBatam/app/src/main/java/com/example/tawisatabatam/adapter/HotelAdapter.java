package com.example.tawisatabatam.adapter;

public class HotelAdapter {
}
